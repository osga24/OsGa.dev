import base64
encoded_string = "TWxzaENURnt5b3Vfa25vd190aGVfcHl0aG9ufQ=="
decoded_bytes = base64.b64decode(encoded_string)
decoded_string = decoded_bytes.decode('utf-8')
print(decoded_string)