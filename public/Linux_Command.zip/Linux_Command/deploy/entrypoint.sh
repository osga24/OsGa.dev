#!/bin/bash
rm -rf /home/ctfuser/challenge
rsync -a /home/ctfuser/challenge_template/ /home/ctfuser/challenge/
rm -rf /home/ctfuser/challenge_template
chmod -R 755 /home/ctfuser/challenge
chown -R ctfuser:ctfuser /home/ctfuser/challenge
/usr/sbin/sshd -D
